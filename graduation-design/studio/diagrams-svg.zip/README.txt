室內設計提案圖說
12張來源解說／概念圖板、28張可編輯向量圖。
概念示意及設計推演，非實測圖；面積、鄰接、動線及成效須另驗證。
來源與界線：https://cathybart5072-arch.github.io/FinalYearProject/graduation-design/studio/
