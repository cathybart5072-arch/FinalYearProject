機能轉移圖解
依來源重繪的解說示意，不是原始照片、實測圖或觀察紀錄。
來源、引用編號與限制：
https://cathybart5072-arch.github.io/FinalYearProject/graduation-design/visuals/
