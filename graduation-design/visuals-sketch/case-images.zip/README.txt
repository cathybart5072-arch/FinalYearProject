鬆線草圖版
8個案例、19项文獻及證據，依来源重繪的解說示意。
不是原始照片、實測圖或觀察紀錄。
來源與研究方法：https://cathybart5072-arch.github.io/FinalYearProject/graduation-design/visuals-sketch/
